const mongoose = require("mongoose");
const productSchema = new mongoose.Schema({
  id: {
    type: String,
   // required: true,
  },
  pname: {
    type: String,
   // required: true,
  },
  price: {
    type: Number,
   // required: true,
  },
  qty: {
    type: Number,
   // required: true,
  },
});
module.exports = mongoose.model("prod", productSchema);
