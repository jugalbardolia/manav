import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addqty, fetchdata, getmob, getname, subqty } from "./billslice";
import axios from "axios";

const Bill = () => {
  const data = useSelector((state) => state.bill.data);
  const name = useSelector((state) => state.bill.name);
  const mobile = useSelector((state) => state.bill.mobile);

  const dispatch = useDispatch();

  var total = 0;

  const getdata = async () => {
    let res = await axios.get("http://localhost:5050/students/getProduct");
    var tempdata = res.data;
    tempdata=tempdata.map(item=>{
      return{
        ...item,
        qty:0
      }
    })
    dispatch(fetchdata(tempdata));
  };

  useEffect(() => {
    getdata();
  }, []);
  //   console.log(data);

  const collectdata = async () => {
    let res = await axios.post(`http://localhost:5050/students/insbill`, {
      name,
      mobile,
      data,
    });
    if (res) {
      alert("order success");
    }
  };

  const dispdata = data.map((d) => {
    total += d.qty * d.price;
    return (
      <tr>
        <th scope="row">{d.id}</th>
        <td>{d.pname}</td>
        <td>Rs. {d.price}</td>
        <td>
          <input
            type="button"
            className="btn btn-primary"
            onClick={(e) => {
              dispatch(addqty(d));
            }}
            value=" + "
          ></input>
          &nbsp; {d.qty} &nbsp;
          <input
            type="button"
            className="btn btn-primary"
            onClick={(e) => {
              dispatch(subqty(d));
            }}
            value=" - "
          ></input>
        </td>
        <td>{d.qty * d.price}</td>
      </tr>
    );
  });

  return (
    <div>
      <h1>Redux Billing</h1>
      <div>
        <h2>R2</h2>
        <hr></hr>
        Enter the name :{" "}
        <input
          type="text"
          onChange={(e) => {
            dispatch(getname(e.target.value));
          }}
        ></input>
        <br />
        <br />
        Enter mob no :{" "}
        <input
          type="number"
          onChange={(e) => {
            dispatch(getmob(e.target.value));
          }}
        ></input>
        <br />
        <br />
        <table >
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Product</th>
              <th scope="col">Price</th>
              <th scope="col">Quantity</th>
              <th scope="col">Total</th>
            </tr>
          </thead>
          <tbody>
            {dispdata}
            <tr>
              <td colSpan="4">Total</td>
              <td>
                <b>{total}</b>
              </td>
            </tr>
          </tbody>
        </table>
        <input
          type="button"
          className="btn btn-primary"
          value={"Place order"}
          onClick={collectdata}
        ></input>
      </div>
    </div>
  );
};

export default Bill;
