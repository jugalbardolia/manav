import { createSlice } from "@reduxjs/toolkit";

export const billslice = createSlice({
  name: "bill",
  initialState: {
    data: [],
    name: "",
    mobile: 0,
    bills: [],
  },
  reducers: {
    fetchdata: (state, ms) => {
      state.data = ms.payload;
    },
    addqty: (state, ms) => {
      state.data = state.data.map((d) => {
        if (d.id === ms.payload.id) {
          return { ...ms.payload, qty: d.qty + 1 };
        } else return d;
      });
    },
    subqty: (state, ms) => {
      state.data = state.data.map((d) => {
        if (d.id === ms.payload.id) {
          if (d.qty > 1) {
            return { ...ms.payload, qty: ms.payload.qty - 1 };
          } else return d;
        } else return d;
      });
    },
    getname: (state, ms) => {
      state.name = ms.payload;
    },
    getmob: (state, ms) => {
      state.mobile = ms.payload;
    },
    getbills: (state, ms) => {
      state.bills = ms.payload;
    },
  },
});
export const { fetchdata, addqty, subqty, getname, getmob, getbills } =
  billslice.actions;
export default billslice.reducer;
