import React from "react";
import Nav from "./Nav";
import { Route, Routes } from "react-router-dom";
import Bill from "./Bill";
import Dispord from "./Dispord";

const Redx_blink = () => {
  return (
    <div>
      <Nav />
      <Routes>
        <Route path="/home" element={<Bill />}></Route>
        <Route path="/disp" element={<Dispord />}></Route>
      </Routes>
    </div>
  );
};

export default Redx_blink;
