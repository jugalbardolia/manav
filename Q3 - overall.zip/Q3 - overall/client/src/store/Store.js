import { configureStore } from "@reduxjs/toolkit";
import billReducer from "../redux_bill/billslice.js";


export const store = configureStore({
  reducer: {
    bill: billReducer,

  },
});
