// import logo from "./logo.svg";
import "./App.css";
import { NavLink, Router } from "react-router-dom";

// import Link from "./usestate_blog/Link";



import Q2_a from "./usestate_bill/Q2_a";
import Link from "./usestate_bill/Link";
import Redx_blink from "./redux_bill/Redx_blink";
import Nav from "./usestate_bill/Nav";

function App() {
  return (
    <div>
     

      {/* usestate bill */}
       <Link /> 

      {/* redux bill */}
      {/* <Redx_blink /> */}

      {/* usestate shopping */}
      {/* <Use_shop /> */}

      {/* redux Shopping */}
      {/* <Redux_shop /> */}
    </div>
  );
}

export default App;
