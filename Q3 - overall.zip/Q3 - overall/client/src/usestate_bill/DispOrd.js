import axios from "axios";
import React, { useEffect, useState } from "react";

const DispOrd = () => {
  const [data, setdata] = useState([]);

  useEffect(() => {
    gatdata();
  }, []);

  const gatdata = async () => {
    let res = await axios.get(`http://localhost:3004/bill/getbills`);
    setdata(res.data);
  };

  const dispdata = data.map((d) => {
    var tot = 0;
    return (
      <tr>
        <td>{d.name}</td>
        <td>{d.mobile}</td>
        <td>
          <table className="table table-light">
            <thead>
              <tr>
                <th>Product name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {d.orders.map((o) => {
                tot += o.price * o.qty;
                return (
                  <tr>
                    <td>{o.pname}</td>
                    <td>{o.price}</td>
                    <td>{o.qty}</td>
                    <td>{o.price * o.qty}</td>
                  </tr>
                );
              })}
              <tr>
                <td colSpan={3}>Total</td>
                <td>
                  <b>{tot}</b>
                </td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr>
    );
  });

  //search data
  const searchdata = async (e) => {
    let key = e.target.value;
    if (key) {
      let res = await axios.get(`http://localhost:5050/students/searchrec/${key}`);
      if (res) {
        setdata(res.data);
      }
    } else {
      gatdata();
    }
  };

  return (
    <div>
      <h2>this is disp order</h2>
      search : <input type="text" onChange={searchdata} name="ser"></input>
      <br />
      <br />
      <table >
        <thead>
          <tr>
            <th>Name</th>
            <th>Mobile no</th>
            <th>orders</th>
          </tr>
        </thead>
        <tbody>{dispdata}</tbody>
      </table>
    </div>
  );
};

export default DispOrd;
